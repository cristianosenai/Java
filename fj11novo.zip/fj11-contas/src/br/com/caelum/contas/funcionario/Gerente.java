package br.com.caelum.contas.funcionario;

public class Gerente extends Funcionario{
	private int senha;
	private int numeroDeFuncionariosGerenciados;

	@Override
	public double getBonificacao() {
		return super.getBonificacao() + 1000;
	}
	
	public boolean autentica(int senha) {
		if (this.senha == senha) {
			System.out.println("Acesso Permitido!");
			return true;
		} else {
			System.out.println("Acesso Negado!\n Procure o Administrador do sistema! ");
			return false;
		}
	}
	// Sobrescrevendo o método getNome
    @Override
	public String getNome() {
		return "Gerente" + super.getNome();// Adiciona "Gerente: " ao nome do funcionário
	}
    // Sobrescrevendo o método setNome
    @Override
	public void setNome(String nome) {
		super.setNome(nome); // Define o nome do funcionário
	}

	public String getCpf() {
		return super.getCpf();
	}

	public void setCpf(String cpf) {
		super.setCpf(cpf);
	}

	public double getSalario() {
		return super.getSalario();
	}

	public void setSalario(double salario) {
		super.setSalario(salario);
	}

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}

	public int getNumeroDeFuncionariosGerenciados() {
		return numeroDeFuncionariosGerenciados;
	}

	public void setNumeroDeFuncionariosGerenciados(int numeroDeFuncionariosGerenciados) {
		this.numeroDeFuncionariosGerenciados = numeroDeFuncionariosGerenciados;
	}
	
}
