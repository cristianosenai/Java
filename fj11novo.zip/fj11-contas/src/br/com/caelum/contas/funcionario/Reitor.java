package br.com.caelum.contas.funcionario;

public class Reitor extends EmpregadoDaFaculdade{
	public String getInfo() {
		return super.getInfo() + " e ele é um reitor";
	}
}
