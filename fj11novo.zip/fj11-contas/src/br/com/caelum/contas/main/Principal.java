package br.com.caelum.contas.main;
import javax.swing.JOptionPane;

import br.com.caelum.contas.modelo.Conta;

public class Principal {
	public static void main(String[] args) {
		Conta conta = new Conta();
		//Conta conta1 = new Conta();
		Conta contaDestino = new Conta();
		/*conta.deposita(100.0);
		System.out.println("Seu Saldo é: R$ " + conta.getSaldo());*/
		
		//Captura os dados para criar uma nova conta
		String titular = JOptionPane.showInputDialog("Digite o nome do titular da conta:");
		int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite o número da conta:"));
		String agencia = JOptionPane.showInputDialog("Digite a agência:");
		conta.setTitular(titular);
		conta.setNumero(numero);
		conta.setAgencia(agencia);
		
		// Obtendo os dados da conta destino manualmente
	    String titularDestino = JOptionPane.showInputDialog("Digite o nome do titular da conta destino:");
	    int numeroDestino = Integer.parseInt(JOptionPane.showInputDialog("Digite o número da conta destino:"));
	    String agenciaDestino = JOptionPane.showInputDialog("Digite a agência da conta destino:");

	    // Criando a conta destino com os dados fornecidos
	    contaDestino.setTitular(titularDestino);
	    contaDestino.setNumero(numeroDestino);
	    contaDestino.setAgencia(agenciaDestino);
		
		/*//Captura os dados para criar uma nova conta
				String titularDestino = JOptionPane.showInputDialog("Digite o nome do titular da conta:");
				int numeroDestino = Integer.parseInt(JOptionPane.showInputDialog("Digite o número da conta:"));
				String agenciaDestino = JOptionPane.showInputDialog("Digite a agência:");
				conta1.setTitular(titularDestino);
				conta1.setNumero(numeroDestino);
				conta1.setAgencia(agenciaDestino);*/
		
		// Exibindo o resultado em uma caixa de diálogo
		//conta.getTitular();
		JOptionPane.showMessageDialog(null, "O titular da conta é: " + conta.getTitular()+"\nO número da conta é: " + conta.getNumero()+"\nA agência é: " + conta.getAgencia());
		JOptionPane.showMessageDialog(null, "O titular da conta destino é: " + contaDestino.getTitular()+"\nO número da conta destino é: " + contaDestino.getNumero()+"\nA agência destino é: " + contaDestino.getAgencia());
		
		//Depósito inicial
		double depositoInicial = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do depósito"));
		conta.deposita(depositoInicial);
		
		//Menu de operações
		String menu = "Escolha uma operação\n";
		menu += "1 - Consultar Saldo\n";
		menu += "2 - Realizar deposito\n";
		menu += "3 - Realizar saque\n";
		menu += "4 - Transferir valor para a outra conta\n";
		menu += "5 - Visualizar dados da conta\n";
		menu += "6 - Sair";
		
		int opcao;
		do {
			opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));
			switch (opcao) {
			case 1:
				JOptionPane.showMessageDialog(null, "Saldo atual: " + conta.getSaldo());
				break;
			case 2:
				double valorDeposito = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do deposito: "));
				conta.deposita(valorDeposito);
				JOptionPane.showMessageDialog(null, "Deposito realizado com sucesso!");
				break;
			case 3:
				double valorSaque = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do saque:"));
				if (conta.saca(valorSaque)) {
					JOptionPane.showMessageDialog(null, "Saque realizado com sucesso!");
				break;
				}
			case 4:
				
			    // Realizando a transferência
			    double valorTransferencia = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor que deseja transferir:"));
			    if (conta.getSaldo() >= valorTransferencia) {
			        conta.transferePara(contaDestino, valorTransferencia);
			        JOptionPane.showMessageDialog(null, "Transferência realizada com sucesso!");
			    } else {
			        JOptionPane.showMessageDialog(null, "Saldo insuficiente para realizar a transferência!");
			    }
			    break;
				
				/*int numeroContaDestino = Integer.parseInt(JOptionPane.showInputDialog("Informe o número da conta destino:"));
			    Conta contaDestino = obterContaPeloNumero(numeroContaDestino);
			    if (contaDestino != null) {
			        double valorTransferencia = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor que deseja transferir:"));
			        conta.transferePara(contaDestino, valorTransferencia);
			        JOptionPane.showMessageDialog(null, "Transferência realizada com sucesso!");
			    } else {
			        JOptionPane.showMessageDialog(null, "Conta destino não encontrada. Verifique o número informado.");
			    }
			    break;*/
			case 5:
				JOptionPane.showMessageDialog(null, conta.recuperaDadosParaImpressao());
				JOptionPane.showMessageDialog(null, contaDestino.recuperaDadosParaImpressao());
				break;
			case 6:
				JOptionPane.showMessageDialog(null, "Obrigado por usar o nosso banco!");
				break;
			} 
		}while (opcao != 6);
	}

	private static Conta obterContaPeloNumero(int i) {
		// TODO Auto-generated method stub
		return null;
	}
}
