package br.com.caelum.contas.main;
import br.com.caelum.javafx.api.main.TelaDeContas;
import br.com.caelum.javafx.api.main.SistemaBancario;
public class TestaContas {

	public static void main(String[] args) {
		SistemaBancario.mostraTela(false);

	}

}
