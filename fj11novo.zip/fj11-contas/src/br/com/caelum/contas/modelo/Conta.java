package br.com.caelum.contas.modelo;

public class Conta {
	protected double saldo;
	private String titular;
	private int numero;
	private String agencia;
	static int contaDestino;

	public int getContaDestino() {
		return contaDestino;
	}

	public void setContaDestino(int contaDestino) {
		this.contaDestino = contaDestino;
	}

	public void deposita(double valor) {
		this.saldo += valor;
	}

	private static Conta obterContaDestino() {
	    Conta contaDestino = new Conta();
	    contaDestino.setNumero(1234); // Defina o número da conta destino como 1234
	    // Você pode definir outros atributos da conta de destino aqui, se necessário.
	    return contaDestino;
	}
	
	public boolean saca(double valor) {
		
		 if (this.saldo < valor || valor < 0) {
		 System.out.println("Saldo insuficiente ou Valor informado inválido!\n");
		 return false;
		 }else { 
			 this.saldo = this.saldo - valor;
		 //System.out.println("Saque no valor de R$: "+valor+"  Realizado com sucesso!\n");
		}
		 return true;
	}
	//transfere valor para outra conta
	public boolean transferePara(Conta destino, double valor) {
		boolean retirou = this.saca(valor);
		if (retirou == false) {
			return false;
		}else {
			destino.deposita(valor);
			return true;
		}
	}
	//recuperar dados para impressão
		public String recuperaDadosParaImpressao() {
			String dados = "\n Titular: " + this.getTitular();
			dados += "\n Número: " + this.getNumero();
			dados += "\n Agência: " + this.getAgencia();
			dados += "\n Saldo: " + this.saldo;
			dados += "\nSeu Saldo Atual é de R$: " + this.saldo;
			return dados;
		}

	public double getSaldo() {
		// TODO Auto-generated method stub
		return this.saldo;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public Object getTipo() {
		// TODO Auto-generated method stub
		return "Conta";
	}
}
